//! `VICTORY_FRAME_CSV=<file>`: a line for every presented frame, in every
//! build. The window's caption shows an average over a second and the log
//! one over five; a hitch of one frame is in neither.
//!
//! Columns, separated by semicolons, with a decimal point (as spreadsheets
//! open it): the line's number, the title's frame number (as the log
//! names frames), milliseconds since the first line, this frame's time from
//! the present before to this one, the draws run on the host in it, and of
//! the frame line's split what is counted as it happens: milliseconds
//! preparing submissions, of them copying title memory and refreshing
//! textures, milliseconds waiting for the GPU, and milliseconds copying back
//! what shaders wrote. Nothing is measured for it: the counters the frame
//! line adds up over a second are read at each present.
//!
//! The present only reads those counters and hands them to a thread of this
//! file's own, which writes the lines and flushes them about once a second
//! (the present holds the presenter's lock: no file is written under it).
//! Unset, a present pays for one look at a `OnceLock`.
//!
//! The file holds numbers of a run of the title: as
//! `victory_core::policy::ensure_outside_repo` has it, it is refused below a
//! source tree (a folder with `.victory-root`). This crate does not depend
//! on `victory-core`, so the ancestors are looked at here.

use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;
use std::sync::atomic::Ordering;
use std::sync::mpsc::{Receiver, RecvTimeoutError, Sender, channel};
use std::time::{Duration, Instant};

/// The marker at the root of a source tree (`victory_core::policy`).
const ROOT_MARKER: &str = ".victory-root";

/// The counters read at a present, microseconds each: preparing, waiting
/// for the GPU, title memory copies, texture refreshes, copying back.
const COUNTERS: usize = 5;

/// What a present saw.
struct Sample {
    frame: u64,
    at: Instant,
    drawn: u64,
    us: [u64; COUNTERS],
    /// The frame line takes the counters back to zero after this one.
    line: bool,
}

enum Told {
    Frame(Sample),
    /// Everything so far is to be in the file; answered when it is.
    Flush(Sender<()>),
}

static OUT: OnceLock<Option<Sender<Told>>> = OnceLock::new();

fn out() -> Option<&'static Sender<Told>> {
    OUT.get_or_init(|| {
        let path = PathBuf::from(std::env::var_os("VICTORY_FRAME_CSV").filter(|v| !v.is_empty())?);
        if below_source_tree(&path) {
            tracing::warn!(
                path = %path.display(),
                "VICTORY_FRAME_CSV: no frame lines are written below the VIctory source tree (see docs/asset-policy.md); name a file outside it"
            );
            return None;
        }
        let file = match std::fs::File::create(&path) {
            Ok(file) => file,
            Err(e) => {
                tracing::warn!(error = %e, path = %path.display(), "VICTORY_FRAME_CSV: the file cannot be written");
                return None;
            }
        };
        let (tx, rx) = channel();
        let spawned = std::thread::Builder::new().name("victory-frame-csv".into()).spawn(move || write(file, &rx));
        if let Err(e) = spawned {
            tracing::warn!(error = %e, "VICTORY_FRAME_CSV: no thread to write the frame lines");
            return None;
        }
        tracing::info!(path = %path.display(), "a line for every presented frame is written (VICTORY_FRAME_CSV)");
        Some(tx)
    })
    .as_ref()
}

/// Whether `path` (which need not exist yet) is below a folder that holds
/// [`ROOT_MARKER`], or cannot be told to be outside one.
fn below_source_tree(path: &Path) -> bool {
    let Ok(absolute) = std::path::absolute(path) else { return true };
    let marked = |p: &Path| p.ancestors().any(|a| a.join(ROOT_MARKER).is_file());
    // Through links too: the nearest folder that is there, as the system
    // resolves it.
    let there = absolute.ancestors().skip(1).find_map(|a| std::fs::canonicalize(a).ok());
    marked(&absolute) || there.is_some_and(|p| marked(&p))
}

/// A frame was presented; `line` says that the frame line follows and takes
/// the counters back to zero.
pub(super) fn presented(line: bool) {
    let Some(out) = out() else { return };
    let preparing = &super::PREPARING;
    let us = [
        super::SUBMISSION_US[0].load(Ordering::Relaxed),
        super::SUBMISSION_US[1].load(Ordering::Relaxed),
        preparing[0].load(Ordering::Relaxed),
        preparing[2].load(Ordering::Relaxed),
        super::COPY_BACK[0].load(Ordering::Relaxed),
    ];
    let sample = Sample { frame: crate::frame::current(), at: Instant::now(), drawn: crate::draw::drawn(), us, line };
    let _ = out.send(Told::Frame(sample));
}

/// At the end of a run: the lines so far are in the file when this returns
/// (or two seconds have passed).
pub(crate) fn flush() {
    let Some(Some(out)) = OUT.get() else { return };
    let (tx, rx) = channel();
    if out.send(Told::Flush(tx)).is_ok() {
        let _ = rx.recv_timeout(Duration::from_secs(2));
    }
}

/// The writing thread.
fn write(file: std::fs::File, told: &Receiver<Told>) {
    let mut file = std::io::BufWriter::new(file);
    let _ = writeln!(file, "present;frame;since_start_ms;frame_ms;draws;preparing_ms;copies_ms;textures_ms;gpu_ms;copy_back_ms");
    let _ = file.flush();
    // The present before: when, the draws by then and the counters then.
    let mut before: Option<(Instant, u64, [u64; COUNTERS])> = None;
    let mut first = None;
    let (mut presents, mut flushed) = (0u64, Instant::now());
    loop {
        match told.recv_timeout(Duration::from_secs(1)) {
            Ok(Told::Frame(s)) => {
                if let Some((at, drawn, us)) = before {
                    presents += 1;
                    let ms = |i: usize| s.us[i].saturating_sub(us[i]) as f64 / 1e3;
                    let _ = writeln!(
                        file,
                        "{presents};{};{:.3};{:.3};{};{:.3};{:.3};{:.3};{:.3};{:.3}",
                        s.frame,
                        s.at.duration_since(*first.get_or_insert(s.at)).as_secs_f64() * 1e3,
                        s.at.duration_since(at).as_secs_f64() * 1e3,
                        s.drawn.saturating_sub(drawn),
                        ms(0),
                        ms(2),
                        ms(3),
                        ms(1),
                        ms(4)
                    );
                }
                before = Some((s.at, s.drawn, if s.line { [0; COUNTERS] } else { s.us }));
            }
            Ok(Told::Flush(done)) => {
                let _ = file.flush();
                let _ = done.send(());
                continue;
            }
            Err(RecvTimeoutError::Timeout) => {}
            Err(RecvTimeoutError::Disconnected) => break,
        }
        if flushed.elapsed() >= Duration::from_secs(1) {
            let _ = file.flush();
            flushed = Instant::now();
        }
    }
    let _ = file.flush();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_file_below_a_source_tree_is_refused() {
        let dir = tempfile::tempdir().unwrap();
        assert!(!below_source_tree(&dir.path().join("frames.csv")));
        assert!(!below_source_tree(&dir.path().join("not").join("there").join("frames.csv")));
        std::fs::write(dir.path().join(ROOT_MARKER), "").unwrap();
        assert!(below_source_tree(&dir.path().join("frames.csv")));
        assert!(below_source_tree(&dir.path().join("not").join("there").join("frames.csv")));
    }
}
