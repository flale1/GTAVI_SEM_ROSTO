//! `VICTORY_MEM_LOG=1`: one WARN line every 30 seconds with the host memory by
//! category: the upload heap (buffers made since the start, and the texture
//! and staging blocks in use and idle), the scratch chunks kept idle, and the
//! title's sections (committed or only reserved). Logging only: nothing it
//! reads changes what is made or kept.

use std::sync::OnceLock;
use std::sync::atomic::{AtomicU64, Ordering};

use crate::host::{ALIVE, MADE};

/// Between two lines.
const EVERY_MS: u64 = 30_000;
/// When the last line was written (0: none yet).
static LAST: AtomicU64 = AtomicU64::new(0);

fn on() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| std::env::var_os("VICTORY_MEM_LOG").is_some_and(|v| v == "1"))
}

const MIB: u64 = 1 << 20;

/// Called once a second by the submission sweep ([`crate::residency::refresh`]).
pub(crate) fn tick() {
    if !on() {
        return;
    }
    let now = crate::host::coarse_ms();
    let last = LAST.load(Ordering::Relaxed);
    if last != 0 && now.saturating_sub(last) < EVERY_MS {
        return;
    }
    LAST.store(now.max(1), Ordering::Relaxed);
    let [texture_blocks, texture_held, staging_blocks] = crate::pool::stats();
    let texture_idle = crate::pool::texture_room();
    let (title_committed, title_reserved) = crate::inplace::section_totals();
    let (made_count, made_bytes) = (MADE[0].load(Ordering::Relaxed), MADE[1].load(Ordering::Relaxed));
    let (scratch_idle_chunks, scratch_idle_bytes) = (ALIVE[3].load(Ordering::Relaxed), ALIVE[4].load(Ordering::Relaxed));
    tracing::warn!(
        upload_buffers_made = made_count,
        upload_made_mib = made_bytes / MIB,
        texture_blocks,
        texture_in_use_mib = texture_held / MIB,
        texture_idle_mib = texture_idle / MIB,
        staging_blocks,
        scratch_idle_chunks,
        scratch_idle_mib = scratch_idle_bytes / MIB,
        title_committed_mib = title_committed / MIB,
        title_reserved_mib = title_reserved / MIB,
        "mem: upload buffers made {made_count} ({} MiB); textures {texture_blocks} blocks, {} MiB in use, {} MiB idle; staging {staging_blocks} blocks; scratch {scratch_idle_chunks} chunks idle, {} MiB; title sections {} MiB committed, {} MiB reserved",
        made_bytes / MIB,
        texture_held / MIB,
        texture_idle / MIB,
        scratch_idle_bytes / MIB,
        title_committed / MIB,
        title_reserved / MIB,
    );
}
