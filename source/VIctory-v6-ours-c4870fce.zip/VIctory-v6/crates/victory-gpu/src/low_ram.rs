//! `VICTORY_LOW_RAM`: smaller host-side caches for PCs with 24 GiB of RAM or
//! less (the card's memory shared with the PC's is counted in the PC's
//! private bytes, so the caches here decide how far those bytes climb).
//!
//! `VICTORY_LOW_RAM=1` turns it on and `VICTORY_LOW_RAM=0` turns it off. Any
//! other value, or no value, means: on when the PC's total physical RAM is
//! 24 GiB or less (`GlobalMemoryStatusEx`), off above that. An explicit
//! setting of a cut's own variable (`VICTORY_WINDOW_KB`, ...) always wins
//! over this switch.

use std::sync::OnceLock;

/// Whether the low-RAM caches are on (see the module docs).
pub(crate) fn low_ram() -> bool {
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| match std::env::var("VICTORY_LOW_RAM").ok().as_deref().map(str::trim) {
        Some("0") => false,
        Some("1") => true,
        _ => total_physical_ram().is_some_and(|total| total <= 24 << 30),
    })
}

/// The PC's total physical RAM in bytes, from `GlobalMemoryStatusEx`.
#[cfg(windows)]
fn total_physical_ram() -> Option<u64> {
    use windows_sys::Win32::System::SystemInformation::{GlobalMemoryStatusEx, MEMORYSTATUSEX};
    // SAFETY: plain data the call fills in.
    let mut m: MEMORYSTATUSEX = unsafe { std::mem::zeroed() };
    m.dwLength = std::mem::size_of::<MEMORYSTATUSEX>() as u32;
    // SAFETY: a sized structure.
    let ok = unsafe { GlobalMemoryStatusEx(&mut m) } != 0;
    ok.then_some(m.ullTotalPhys)
}

#[cfg(not(windows))]
fn total_physical_ram() -> Option<u64> {
    None
}
